<?php
if (isset($_POST['add_wilayah'])) {

   $id      = $_POST['id'];
   $wilayah   = $_POST['wilayah'];

   if ($id == null || $wilayah == null) {

      echo '<script type="text/javascript">alert("Semua Form Harus Terisi");window.history.go(-1);</script>';

   } else {

      $sql = $con->prepare("INSERT INTO t_wilayah(id_wilayah, nama_wilayah) VALUES ( ?, ?)");
      $sql->bind_param('ss', $id, $wilayah);
      $sql->execute();

      header('location:?page=wilayah');
   }
}

if(!isset($_SESSION['id_admin'])) {
   header('location: ../');
}

$id = mysqli_query($con, "SELECT id_wilayah FROM t_wilayah ORDER BY id_wilayah DESC LIMIT 1");

if (mysqli_num_rows($id) > 0) {
   $key        = mysqli_fetch_array($id);
   $get        = (intval(substr($key['id_wilayah'], 1))) + 1;
   $id_wilayah   = "W".sprintf("%02d", $get);
} else {
   $id_wilayah = 'W01';
}

?>
<h3>Tambah Wilayah</h3>
<hr />
<div class="row">
    <div class="col-md-4">
        <form action="" method="post">

            <div class="form-group">
                <label>Id Wilayah</label>
                <input class="form-control" type="text" name="id" readonly value="<?php echo $id_wilayah; ?>" />
            </div>

            <div class="form-group">
                <label>Nama Wilayah</label>
                <input class="form-control" name="wilayah" type="text" placeholder="Nama Wilayah" />
            </div>

            <div class="form-group">
                <button type="submit" name="add_wilayah" value="Tambah Wilayah" class="btn btn-success">
                    Tambah Kelas
                </button>
                <button type="button" onclick="window.history.go(-1)" class="btn btn-danger">
                    Kembali
                </button>
            </div>

        </form>
    </div>
</div>
