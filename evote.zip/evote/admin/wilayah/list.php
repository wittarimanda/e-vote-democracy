<?php
if(!isset($_SESSION['id_admin'])) {
   header('location: ../');
}
?>
<div class="col-md-9">
   <h3>Daftar Wilayah</h3>
</div>
<div class="col-md-3" style="padding-top:10px;">
   <a class="btn btn-primary" href="?page=wilayah&action=tambah">Tambah Wilayah</a>
</div>
<div style="clear:both"></div>
<hr />
<div class="row">
   <div class="col-md-8">
      <table class="table table-striped">
         <thead>
            <tr>
               <th width="80px" style="text-align:center;">#</th>
               <th style="text-align:center;">Nama Wilayah</th>
               <th width="150px" style="text-align:center;">Jumlah Warga</th>
               <th width="200px" style="text-align:center;">Opsi</th>
            </tr>
         </thead>
         <tbody>
            <?php
            require('../include/connection.php');
            $sql = mysqli_query($con, "SELECT a.*, (SELECT COUNT(id_wilayah) FROM t_user WHERE id_wilayah = a.id_wilayah) AS jumlah FROM t_wilayah a ORDER BY a.id_wilayah ASC");

            if (mysqli_num_rows($sql) > 0) {

               while($data = mysqli_fetch_array($sql)) {
                  ?>
                  <tr>
                     <td style="text-align:center; vertical-align:middle">
                        <?php echo $data['id_wilayah']; ?>
                     </td>
                     <td style="text-align:center; vertical-align:middle">
                        <?php echo $data['nama_wilayah']; ?>
                     </td>
                     <td style="text-align:center; vertical-align:middle">
                        <?php echo $data['jumlah']; ?> Siswa
                     </td>
                     <td style="text-align:center;">
                        <a href="?page=wilayah&action=edit&id=<?php echo $data['id_wilayah']; ?>" class="btn btn-warning btn-sm">
                           Edit
                        </a>
                        <a href="?page=wilayah&action=hapus&id=<?php echo $data['id_wilayah']; ?>" onclick="return confirm('Yakin Ingin Menghapus Wilayah Ini ?');" class="btn btn-danger btn-sm">
                           Hapus
                        </a>
                     </td>
                  </tr>
                  <?php
               }
            } else {

               echo "<tr>
                        <td colspan='4' style='text-align:center;'><h4>Belum Ada Data</h4></td>
                     </tr>";
            }
            ?>
         </tbody>
      </table>
   </div>
</div>
