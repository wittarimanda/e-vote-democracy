<?php
define('BASEPATH', dirname(__FILE__));

session_start();
if(!isset($_SESSION['id_admin'])) {

   header('location:../');

}

if (isset($_POST['update'])) {
   //include file koneksi
   include('../../include/connection.php');
   //tampung data dari form
   $id    = strip_tags(mysqli_real_escape_string($con, $_POST['id']));
   $wilayah = strip_tags(mysqli_real_escape_string($con, $_POST['wilayah']));

   if ($id == null || $wilayah == null) {

      echo '<script type="text/javascript">alert("Form Harus Terisi");window.history.go(-1);</script>';

   } else {

      $sql = $con->prepare("UPDATE t_wilayah SET nama_wilayah = ? WHERE id_wilayah = ?");
      $sql->bind_param('ss', $wilayah, $id);
      $sql->execute();

      header('location:../dashboard.php?page=wilayah');

   }

} else {

   header('location:../dashboard.php');

}
