<?php
if (!isset($_POST['update'])) {

   header('location: ../');

} else {
   define('BASEPATH', dirname(__FILE__));

   include('../../include/connection.php');

   $nis  = $_POST['nik'];
   $nama = $_POST['nama'];
   $jk   = $_POST['jk'];
   $kls  = $_POST['wilayah'];
   $pil  = $_POST['pemilih'];

   if($nik == '' || $nama == '' || $jk == '' || $wilayah == '') {

      echo '<script type="text/javascript">alert("Semua Form Harus Terisi");window.history.go(-1);</script>';

   } else if(!preg_match("/^[a-zA-z \'.]*$/",$nama)) {

      echo '<script type="text/javascript">alert("Nama Hanya Boleh Mengandung Huruf, titik(.), petik tunggal");window.history.go(-1)</script>';

   } else {

      $sql = $con->prepare("UPDATE t_user SET fullname = ?, id_wilayah = ?, jk = ?, pemilih = ? WHERE id_user = ?");
      $sql->bind_param('sssss', $nama, $wilayah, $jk, $pil, $nik);
      $sql->execute();

      header('location:../dashboard.php?page=user');

   }

}

?>
