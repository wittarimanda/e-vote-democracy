<div class="welcome">
   <h2>Selamat Datang di E-Voting</h2>
   <p style="font-size:18px;">Anda Login Sebagai <strong><?php echo $_SESSION['user']; ?></strong> Dengan Hak Akses Terbatas</p>
</div>
