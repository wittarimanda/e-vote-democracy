<?php
defined('BASEPATH') or die("No Access Allowed");
?>
<div class="text-center" style="padding-top:20px;padding-bottom:40px;">
   <div style="padding-bottom:10px">
      <img src="./assets/img/indonesia.png" class="img-thanks" alt="Slideshow 1" >
   </div>
   <h2>Terima Kasih Atas Partisipasi Anda</h2>
   <p>Suara Yang Anda Berikan Menentukan Masa Depan Indonesia</p>
   <a href="./" class="button alert large">Back to Home</a>
</div>
